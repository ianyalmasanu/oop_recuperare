#include <iostream>
using namespace std;
class Ticket {
	const int id;
	static int no_of_tickets;
	char* event_title;
	string date;
	string location;
	int price;
	int* price_history;

	//to-do
	//default constructor
public:
	//Ticket(){
	//}

	//constructor with params
	Ticket(const int id, static int no_of_tickets, char* event_title, string date, string location, int price)
	{
		this->id = id;
		this->no_of_tickets = no_of_tickets;
		this->date = date;
		this->location = location;

	}


	//copy constructor

	//operator =

	//setters

	//getters

	//operator ! which deletes the price history






};